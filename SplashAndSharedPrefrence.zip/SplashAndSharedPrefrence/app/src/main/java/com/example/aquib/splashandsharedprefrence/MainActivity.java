package com.example.aquib.splashandsharedprefrence;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.aquib.splashandsharedprefrence.app.ASAppSharedPrefrences;

public class MainActivity extends AppCompatActivity {

    private ASAppSharedPrefrences mSharedPrefrence;

    private int mClassToOpen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSharedPrefrence = ASAppSharedPrefrences.getSharedPrefInstance(this);
        String CheckLogin = mSharedPrefrence.getLoginStatus();
        int secondsDelayed = 3;
        mClassToOpen = Integer.valueOf(CheckLogin);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                loadSuitableActivity();
            }
        },secondsDelayed*1000);


    }

    public void loadSuitableActivity() {
        if(mClassToOpen == 0)
        {
            Toast.makeText(this, "This is Not Logged in ", Toast.LENGTH_SHORT).show();
           // finish();
        }
        else
        {
//            startActivity(new Intent(MainActivity.this, MainActivity.class));
//            finish();
            Toast.makeText(this, "This is Logged in", Toast.LENGTH_SHORT).show();
        }
    }
}
