package com.example.aquib.splashandsharedprefrence.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

/**
 * Created by AQUIB on 14/7/16.
 *
 */
public class ASAppSharedPrefrences {

    private static ASAppSharedPrefrences asAppSharedPrefrences;
    private SharedPreferences appSharedPrefs;
    public static final String MyPREFERENCES = "MyPrefs";
    private Editor prefsEditor;

    public ASAppSharedPrefrences(Context applicationContext) {
        appSharedPrefs = applicationContext.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
    }

    public static ASAppSharedPrefrences getSharedPrefInstance(Context con)
    {
        if(asAppSharedPrefrences == null) {
            asAppSharedPrefrences = new ASAppSharedPrefrences(con.getApplicationContext());
        }
            return asAppSharedPrefrences;
    }



    public void setLoginStatus(String LoginStatus)
    {
        this.prefsEditor = appSharedPrefs.edit();
        prefsEditor.putString("LoginStatus",LoginStatus);
        prefsEditor.apply();
    }

    public String getLoginStatus()
    {
        return appSharedPrefs.getString("LoginStatus","0");
    }

}
